from django.apps import AppConfig


class CafeAppConfig(AppConfig):
    name = 'cafe_app'
